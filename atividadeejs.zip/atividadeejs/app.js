const express = require("express");
const app = express();

let tasks = [];
let proximoId = 1;

app.set("view engine", "ejs");
app.set("views", __dirname + "/views");

app.use(express.static(__dirname + "/public"));
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
    const concluidas = tasks.filter(t => t.concluido).length;
    res.render("pages/home", {
        pagina: "home",
        total: tasks.length,
        concluidas,
        pendentes: tasks.length - concluidas
    });
});

app.get("/tarefas", (req, res) => {
    res.render("pages/tarefas", { pagina: "tarefas", tasks });
});

app.get("/editar/:id", (req, res) => {
    const task = tasks.find(t => t.id === Number(req.params.id));
    if (!task) {
        return res.redirect("/tarefas");
    }
    res.render("pages/editar", { pagina: "tarefas", task });
});

app.get("/sobre", (req, res) => {
    res.render("pages/sobre", { pagina: "sobre" });
});

app.post("/criar", (req, res) => {
    const nome = (req.body.name || "").trim();
    if (nome !== "") {
        tasks.push({ id: proximoId++, name: nome, concluido: false });
    }
    res.redirect("/tarefas");
});

app.post("/alterar/:id", (req, res) => {
    const task = tasks.find(t => t.id === Number(req.params.id));
    const nome = (req.body.name || "").trim();
    if (task && nome !== "") {
        task.name = nome;
    }
    res.redirect("/tarefas");
});

app.post("/concluir/:id", (req, res) => {
    const task = tasks.find(t => t.id === Number(req.params.id));
    if (task) {
        task.concluido = !task.concluido;
    }
    res.redirect("/tarefas");
});

app.post("/remover/:id", (req, res) => {
    tasks = tasks.filter(t => t.id !== Number(req.params.id));
    res.redirect("/tarefas");
});

app.post("/limpar", (req, res) => {
    tasks = [];
    res.redirect("/tarefas");
});

app.listen(3000, () => {
    console.log("Servidor rodando em http://localhost:3000");
});
